document.addEventListener('DOMContentLoaded', function() {
  const startRegisterBtn = document.getElementById('startRegisterBtn');
  const analyzeBtn = document.getElementById('analyzeBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const status = document.getElementById('status');
  const tokenStatus = document.getElementById('tokenStatus');
  const remainingCount = document.getElementById('remainingCount');

  // 加载当前状态
  chrome.storage.sync.get(['apiToken', 'tokenStatus'], function(result) {
    // 更新Token信息
    if (result.apiToken) {
      tokenStatus.textContent = '已设置';
      tokenStatus.style.color = '#28a745';

      // 检查真实的Token状态
      checkTokenStatus();
    } else {
      tokenStatus.textContent = '未设置';
      tokenStatus.style.color = '#dc3545';
      remainingCount.textContent = '未配置Token';
    }
  });

  // 执行一次注册
  startRegisterBtn.addEventListener('click', function() {
    chrome.storage.sync.get(['apiToken'], function(result) {
      if (!result.apiToken) {
        showStatus('请先在设置中配置API Token', 'error');
        return;
      }

      // 禁用按钮防止重复点击
      startRegisterBtn.disabled = true;
      startRegisterBtn.textContent = '注册中...';

      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'executeRegistration'
        }, function(response) {
          // 恢复按钮状态
          startRegisterBtn.disabled = false;
          startRegisterBtn.textContent = '执行一次注册';

          if (response && response.success) {
            showStatus('注册完成！', 'success');
            // 更新剩余次数
            if (response.remaining !== undefined) {
              remainingCount.textContent = response.remaining;
              remainingCount.style.color = response.remaining > 10 ? '#28a745' : '#dc3545';
            }
          } else {
            showStatus('注册失败: ' + (response?.error || '未知错误'), 'error');
          }
        });
      });
    });
  });

  // 分析页面按钮
  analyzeBtn.addEventListener('click', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'analyzePage'
      }, function(response) {
        if (response) {
          console.log('页面分析结果:', response);
          showStatus(`页面分析完成，请查看控制台`, 'success');
        } else {
          showStatus('页面分析失败', 'error');
        }
      });
    });
  });

  // 设置按钮
  settingsBtn.addEventListener('click', function() {
    chrome.tabs.create({url: 'options.html'});
  });



  // 检查Token状态
  async function checkTokenStatus() {
    const settings = await new Promise(resolve => {
      chrome.storage.sync.get(['apiToken'], resolve);
    });

    if (!settings.apiToken) {
      remainingCount.textContent = '未配置Token';
      return;
    }

    try {
      remainingCount.textContent = '检查中...';

      // 调用真实的API检查Token状态
      const response = await fetch('https://gomail-app.3586177963.workers.dev/api/external/mailbox', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${settings.apiToken}`,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (data.success && data.data) {
        const tokenData = data.data;
        if (tokenData.usageLimit === 0) {
          remainingCount.textContent = '无限次';
          remainingCount.style.color = '#28a745';
        } else {
          const remaining = tokenData.remainingUsage || 0;
          remainingCount.textContent = `剩余 ${remaining} 次`;
          remainingCount.style.color = remaining > 10 ? '#28a745' : '#dc3545';
        }
      } else {
        remainingCount.textContent = 'Token无效';
        remainingCount.style.color = '#dc3545';
      }
    } catch (error) {
      console.error('检查Token状态失败:', error);
      remainingCount.textContent = '检查失败';
      remainingCount.style.color = '#dc3545';
    }
  }

  function showStatus(message, type) {
    status.textContent = message;
    status.className = `status ${type}`;
    status.style.display = 'block';

    setTimeout(() => {
      status.style.display = 'none';
    }, 3000);
  }
});
