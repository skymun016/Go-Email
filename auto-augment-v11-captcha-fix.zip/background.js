// Auto Augment Background Script
console.log('Auto Augment background script loaded');

// 安装时的初始化
chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === 'install') {
    console.log('Auto Augment extension installed');
    
    // 设置默认配置
    chrome.storage.sync.set({
      autoAugmentEnabled: false,
      enhancementLevel: 'medium',
      customSettings: {}
    });
  }
});

// 监听来自content script的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  console.log('Background received message:', request);
  
  switch(request.action) {
    case 'getSettings':
      chrome.storage.sync.get(null, function(settings) {
        sendResponse(settings);
      });
      return true; // 保持消息通道开放
      
    case 'saveSettings':
      chrome.storage.sync.set(request.settings, function() {
        sendResponse({success: true});
      });
      return true;
      
    default:
      sendResponse({error: 'Unknown action'});
  }
});

// 监听标签页更新
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'complete' && tab.url) {
    // 页面加载完成后可以执行一些操作
    console.log('Tab updated:', tab.url);
  }
});
