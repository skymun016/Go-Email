document.addEventListener('DOMContentLoaded', function() {
  const apiToken = document.getElementById('apiToken');
  const remainingCount = document.getElementById('remainingCount');
  const checkTokenBtn = document.getElementById('checkTokenBtn');
  const targetUrl = document.getElementById('targetUrl');
  const saveBtn = document.getElementById('saveBtn');
  const status = document.getElementById('status');

  // 加载当前设置
  loadSettings();

  // 检查Token状态
  checkTokenBtn.addEventListener('click', function() {
    const token = apiToken.value.trim();
    if (!token) {
      showStatus('请先输入API Token', 'error');
      return;
    }
    checkTokenStatus(token);
  });

  // 保存设置
  saveBtn.addEventListener('click', function() {
    const settings = {
      apiToken: apiToken.value.trim(),
      targetUrl: targetUrl.value.trim()
    };

    chrome.storage.sync.set(settings, function() {
      showStatus('设置已保存', 'success');

      // 通知所有标签页设置已更新
      chrome.tabs.query({}, function(tabs) {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, {
            action: 'settingsUpdated',
            settings: settings
          }).catch(() => {
            // 忽略无法发送消息的标签页
          });
        });
      });
    });
  });

  function loadSettings() {
    chrome.storage.sync.get([
      'apiToken',
      'targetUrl'
    ], function(result) {
      apiToken.value = result.apiToken || '';
      targetUrl.value = result.targetUrl || 'https://login.augmentcode.com/u/login/identifier?state=hKFo2SBaQnB6T1RHNDQtcUZXUlladGQxRGlac1N4c3dUSU9ZT6Fur3VuaXZlcnNhbC1sb2dpbqN0aWTZIFhUakJpSUJlaFc0TFZramxpdWpvQVBLR2psWGVJVEwto2NpZNkgd2xMVFZXR0RmSXRXOUh6aUlvd1NSaWVRTlJ5bE1QVGE';

      // 如果有token，自动检查状态
      if (result.apiToken) {
        checkTokenStatus(result.apiToken);
      }
    });
  }

  async function checkTokenStatus(token) {
    remainingCount.textContent = '检查中...';
    remainingCount.style.color = '#666';

    try {
      // 调用真实的API检查Token状态
      const response = await fetch('https://gomail-app.3586177963.workers.dev/api/external/mailbox', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();

      if (data.success && data.data) {
        const tokenData = data.data;
        let remainingText;
        let color;

        if (tokenData.usageLimit === 0) {
          remainingText = '无限次';
          color = '#28a745';
        } else {
          const remaining = tokenData.remainingUsage || 0;
          remainingText = `剩余 ${remaining} 次`;
          color = remaining > 10 ? '#28a745' : '#dc3545';
        }

        remainingCount.textContent = remainingText;
        remainingCount.style.color = color;

        // 保存检查结果
        chrome.storage.sync.set({
          tokenStatus: {
            remaining: remainingText,
            lastCheck: Date.now()
          }
        });

        showStatus('Token状态检查完成', 'success');
      } else {
        remainingCount.textContent = 'Token无效';
        remainingCount.style.color = '#dc3545';
        showStatus('Token无效或已过期', 'error');
      }
    } catch (error) {
      console.error('检查Token状态失败:', error);
      remainingCount.textContent = '检查失败';
      remainingCount.style.color = '#dc3545';
      showStatus('检查Token状态失败: ' + error.message, 'error');
    }
  }

  function showStatus(message, type) {
    status.textContent = message;
    status.className = `status ${type}`;
    status.style.display = 'block';

    setTimeout(() => {
      status.style.display = 'none';
    }, 3000);
  }
});
