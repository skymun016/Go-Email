// Auto Augment Content Script - 邮箱注册机
console.log('邮箱注册机 content script loaded');

// 监听来自popup的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'executeRegistration') {
    executeRegistration().then(result => {
      sendResponse(result);
    }).catch(error => {
      sendResponse({success: false, error: error.message});
    });
    return true; // 保持消息通道开放
  }

  if (request.action === 'analyzePage') {
    const analysis = analyzePage();
    sendResponse(analysis);
    return true;
  }
});

// 分析页面结构（调试用）
function analyzePage() {
  const analysis = {
    url: window.location.href,
    inputs: [],
    checkboxes: [],
    buttons: [],
    forms: []
  };

  // 分析输入框
  document.querySelectorAll('input').forEach((input, index) => {
    analysis.inputs.push({
      index,
      type: input.type,
      name: input.name,
      id: input.id,
      placeholder: input.placeholder,
      className: input.className
    });
  });

  // 分析复选框
  document.querySelectorAll('input[type="checkbox"]').forEach((checkbox, index) => {
    analysis.checkboxes.push({
      index,
      name: checkbox.name,
      id: checkbox.id,
      className: checkbox.className,
      checked: checkbox.checked
    });
  });

  // 分析按钮
  document.querySelectorAll('button, input[type="submit"], input[type="button"]').forEach((button, index) => {
    analysis.buttons.push({
      index,
      type: button.type,
      textContent: button.textContent?.trim(),
      value: button.value,
      className: button.className,
      disabled: button.disabled
    });
  });

  // 分析表单
  document.querySelectorAll('form').forEach((form, index) => {
    analysis.forms.push({
      index,
      action: form.action,
      method: form.method,
      className: form.className
    });
  });

  console.log('页面分析结果:', analysis);
  return analysis;
}

// 执行注册流程
async function executeRegistration() {
  try {
    console.log('开始执行注册流程...');

    // 检查是否在正确的页面
    if (!window.location.href.includes('login.augmentcode.com')) {
      throw new Error('请在 Augment 登录页面使用此功能');
    }

    // 第一步：获取临时邮箱
    const email = await getTempEmail();
    console.log('获取到邮箱:', email);

    // 第二步：填入邮箱
    await fillEmailInput(email);

    // 第三步：点击人机验证
    await clickCaptcha();

    // 第四步：点击继续按钮
    await clickContinueButton();

    console.log('注册流程执行完成');
    return {
      success: true,
      email: email,
      message: '注册流程执行完成'
    };

  } catch (error) {
    console.error('注册流程失败:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// 获取临时邮箱
async function getTempEmail() {
  // 从存储中获取API配置
  const settings = await new Promise(resolve => {
    chrome.storage.sync.get(['apiToken', 'targetUrl'], resolve);
  });

  if (!settings.apiToken) {
    throw new Error('请先在设置中配置API Token');
  }

  try {
    // 调用真实的临时邮箱API
    const response = await fetch('https://gomail-app.3586177963.workers.dev/api/external/mailbox', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${settings.apiToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prefix: 'auto',
        domain: '184772.xyz'
      })
    });

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.error || 'API调用失败');
    }

    console.log('API响应:', data);
    return data.data.email;

  } catch (error) {
    console.error('获取临时邮箱失败:', error);
    throw new Error(`获取临时邮箱失败: ${error.message}`);
  }
}

// 填入邮箱地址
async function fillEmailInput(email) {
  return new Promise((resolve, reject) => {
    // 等待页面加载完成
    setTimeout(() => {
      // 多种方式查找邮箱输入框 - 针对Auth0页面优化
      let emailInput = document.querySelector('input[type="email"]') ||
                      document.querySelector('input[name="username"]') ||
                      document.querySelector('input[name="email"]') ||
                      document.querySelector('input[placeholder*="邮箱"]') ||
                      document.querySelector('input[placeholder*="email"]') ||
                      document.querySelector('input[placeholder*="电子邮件"]') ||
                      document.querySelector('input[id*="email"]') ||
                      document.querySelector('input[id*="username"]') ||
                      document.querySelector('input[autocomplete="email"]') ||
                      document.querySelector('input[autocomplete="username"]') ||
                      // Auth0 specific selectors
                      document.querySelector('.auth0-lock-input[type="email"]') ||
                      document.querySelector('.auth0-lock-input[name="username"]') ||
                      document.querySelector('.auth0-lock-input[name="email"]');

      // 如果还没找到，尝试通过标签文本查找
      if (!emailInput) {
        const labels = document.querySelectorAll('label');
        for (let label of labels) {
          const text = label.textContent?.toLowerCase() || '';
          if (text.includes('邮箱') || text.includes('email') || text.includes('电子邮件')) {
            const forId = label.getAttribute('for');
            if (forId) {
              emailInput = document.getElementById(forId);
              break;
            }
            // 如果没有for属性，查找相邻的input
            const input = label.querySelector('input') ||
                         label.nextElementSibling?.querySelector('input') ||
                         label.previousElementSibling?.querySelector('input');
            if (input) {
              emailInput = input;
              break;
            }
          }
        }
      }

      // 如果还没找到，查找所有input，看哪个可能是邮箱输入框
      if (!emailInput) {
        const inputs = document.querySelectorAll('input[type="text"], input:not([type])');
        for (let input of inputs) {
          const placeholder = input.placeholder?.toLowerCase() || '';
          const name = input.name?.toLowerCase() || '';
          const id = input.id?.toLowerCase() || '';

          if (placeholder.includes('email') || placeholder.includes('邮箱') ||
              name.includes('email') || name.includes('邮箱') ||
              id.includes('email') || id.includes('邮箱')) {
            emailInput = input;
            break;
          }
        }
      }

      if (!emailInput) {
        reject(new Error('未找到邮箱输入框，请检查页面是否正确加载'));
        return;
      }

      // 清空并填入邮箱
      emailInput.value = '';
      emailInput.focus();

      // 模拟真实的用户输入
      for (let i = 0; i < email.length; i++) {
        setTimeout(() => {
          emailInput.value = email.substring(0, i + 1);
          emailInput.dispatchEvent(new Event('input', { bubbles: true }));
        }, i * 50);
      }

      // 触发change事件
      setTimeout(() => {
        emailInput.dispatchEvent(new Event('change', { bubbles: true }));
        emailInput.dispatchEvent(new Event('blur', { bubbles: true }));
        console.log('邮箱已填入:', email);
        resolve();
      }, email.length * 50 + 100);

    }, 1000);
  });
}

// 点击人机验证复选框
async function clickCaptcha() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      console.log('开始查找人机验证复选框...');

      // 首先查找所有checkbox，看看页面上有哪些
      const allCheckboxes = document.querySelectorAll('input[type="checkbox"]');
      console.log('页面上找到的所有checkbox:', allCheckboxes.length);

      let captchaCheckbox = null;

      // 方法1: 直接查找checkbox
      if (allCheckboxes.length === 1) {
        captchaCheckbox = allCheckboxes[0];
        console.log('找到唯一的checkbox，假设是人机验证');
      }

      // 方法2: 查找包含"human"或"verify"文本的相关checkbox
      if (!captchaCheckbox) {
        const textElements = document.querySelectorAll('span, label, div');
        for (let element of textElements) {
          const text = element.textContent?.toLowerCase() || '';
          if (text.includes('verify you are human') ||
              text.includes('human') ||
              text.includes('verify') ||
              text.includes('captcha') ||
              text.includes('robot')) {
            console.log('找到包含验证文本的元素:', text);

            // 查找同级或父级的checkbox
            const parentContainer = element.parentElement;
            if (parentContainer) {
              const checkbox = parentContainer.querySelector('input[type="checkbox"]');
              if (checkbox) {
                captchaCheckbox = checkbox;
                console.log('在相关容器中找到checkbox');
                break;
              }
            }

            // 查找前面的兄弟元素
            let sibling = element.previousElementSibling;
            while (sibling) {
              if (sibling.tagName === 'INPUT' && sibling.type === 'checkbox') {
                captchaCheckbox = sibling;
                console.log('在前面的兄弟元素中找到checkbox');
                break;
              }
              sibling = sibling.previousElementSibling;
            }

            if (captchaCheckbox) break;
          }
        }
      }

      // 方法3: 查找特定class的checkbox容器
      if (!captchaCheckbox) {
        const containers = document.querySelectorAll('[class*="cb-"], [class*="captcha"], [class*="verify"]');
        for (let container of containers) {
          const checkbox = container.querySelector('input[type="checkbox"]');
          if (checkbox) {
            captchaCheckbox = checkbox;
            console.log('在特定class容器中找到checkbox');
            break;
          }
        }
      }

      if (!captchaCheckbox) {
        console.error('未找到人机验证复选框');
        console.log('页面HTML结构:', document.body.innerHTML.substring(0, 1000));
        reject(new Error('未找到人机验证复选框，请检查页面是否正确加载'));
        return;
      }

      console.log('找到人机验证复选框:', captchaCheckbox);

      // 检查是否已经选中
      if (captchaCheckbox.checked) {
        console.log('人机验证复选框已经选中');
        resolve();
        return;
      }

      // 点击复选框
      console.log('点击人机验证复选框...');
      captchaCheckbox.click();
      console.log('人机验证复选框已点击');

      // 等待一段时间确保验证完成
      setTimeout(resolve, 2000);
    }, 500);
  });
}

// 点击继续按钮
async function clickContinueButton() {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // 多种方式查找继续按钮
      let continueBtn = document.querySelector('button[type="submit"]') ||
                       document.querySelector('input[type="submit"]') ||
                       document.querySelector('[data-testid*="continue"]') ||
                       document.querySelector('.continue-btn') ||
                       document.querySelector('.submit-btn');

      // 通过文本内容查找按钮
      if (!continueBtn) {
        const buttons = document.querySelectorAll('button, input[type="button"], input[type="submit"]');
        for (let btn of buttons) {
          const text = btn.textContent?.trim() || btn.value?.trim() || '';
          if (text.includes('继续') || text.includes('Continue') ||
              text.includes('提交') || text.includes('Submit') ||
              text.includes('下一步') || text.includes('Next')) {
            continueBtn = btn;
            break;
          }
        }
      }

      // 如果还没找到，查找form中的提交按钮
      if (!continueBtn) {
        const forms = document.querySelectorAll('form');
        for (let form of forms) {
          const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]') ||
                           form.querySelector('button:last-child') ||
                           form.querySelector('button');
          if (submitBtn) {
            continueBtn = submitBtn;
            break;
          }
        }
      }

      if (!continueBtn) {
        reject(new Error('未找到继续按钮，请检查页面是否正确加载'));
        return;
      }

      // 检查按钮是否可点击
      if (continueBtn.disabled) {
        reject(new Error('继续按钮当前不可点击，请检查是否完成了前面的步骤'));
        return;
      }

      // 点击按钮
      continueBtn.click();
      console.log('继续按钮已点击');

      setTimeout(resolve, 1500);
    }, 500);
  });
}
